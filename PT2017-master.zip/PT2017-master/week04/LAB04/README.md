Lab #4
==================
Разобрать и реализовать алгоритм перевода обычного математического выражения в обратную польскую нотацию.
Ссылки 

* https://ru.wikipedia.org/wiki/Обратная_польская_запись

* https://habrahabr.ru/post/100869/

* http://primat.org/news/obratnaja_polskaja_zapis/2016-04-09-1181 

* http://trubetskoy1.narod.ru/ppn.html