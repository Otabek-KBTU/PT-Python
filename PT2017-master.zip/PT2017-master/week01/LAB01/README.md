Lab #1
==================
Solve problems using python:
* http://informatics.mccme.ru/mod/statements/view3.php?id=2296&chapterid=2944
* http://informatics.mccme.ru/mod/statements/view3.php?id=2296&chapterid=2949
* http://informatics.mccme.ru/mod/statements/view3.php?id=276&chapterid=260
* http://informatics.mccme.ru/mod/statements/view3.php?id=276&chapterid=295
* http://informatics.mccme.ru/mod/statements/view3.php?id=276&chapterid=301
* http://informatics.mccme.ru/mod/statements/view3.php?id=278&chapterid=315
* http://informatics.mccme.ru/mod/statements/view3.php?id=278&chapterid=320
* http://informatics.mccme.ru/mod/statements/view3.php?id=278&chapterid=321
* http://informatics.mccme.ru/mod/statements/view3.php?id=2585&chapterid=3068
* http://informatics.mccme.ru/mod/statements/view3.php?id=2741&chapterid=3162
* http://informatics.mccme.ru/mod/statements/view3.php?id=2741&chapterid=3167
* http://informatics.mccme.ru/mod/statements/view3.php?id=282&chapterid=362
* http://informatics.mccme.ru/mod/statements/view.php?id=268
