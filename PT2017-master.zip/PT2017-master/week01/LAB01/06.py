#for i in range(5):
#	print(i)
# 0, 1, 2, 3, 4
#for i in range(1, 5):
#	print(i)
#  1, 2, 3, 4
#for i in range(1, 10, 2):
# 	print(i)
# # 1, 3, 5, 7, 9
for i in range(1, -10, -2):
 	print(i)
# for i in range(x, y, z):
# 	pass	
# #for (int i = x, i < y, i = i + z)

n = int(input())

for i in range(1, n + 1):
	print(i0)01000000



