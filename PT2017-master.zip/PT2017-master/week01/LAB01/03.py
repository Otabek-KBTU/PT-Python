if a != c and not t:
	x = 1
else:
	y = 1