a = input()
b = input()
a, b = b, a
# cout << a << " " << b;
print(a + " " + b)