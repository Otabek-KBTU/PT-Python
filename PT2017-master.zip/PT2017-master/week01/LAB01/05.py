import math

x = math.sqrt(27)