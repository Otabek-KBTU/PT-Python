Lab #3
==================
Write and check regular expressions for:

* email (gmail.com, mail.ru, yandex.ru, icloud.com)
* Kazakhstan mobile phone +7 7015209278
* Kazakhstan city phone +7 7273 56 67 78
* Kazakhstan old state vehicle number A 777 AV, A 777 MOM
* Kazakhstan new state vehicle number 040TBA02
* IIN Individual identification number 900830351134
