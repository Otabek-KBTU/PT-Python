Serialization
==================

Pass the following tutorials:

- XML https://www.w3schools.com/Xml/ until namespaces

- JSON https://www.w3schools.com/js/js_json_intro.asp until Parse