from PIL import Image, ImageDraw, ImageFont

file = sys.argv