Lab #9
==================

Face detection
_________________

- collect 10 passport photo

- collect 10 non-face photo

- write python script detecting face in file 