# PT2017
Programming Technologies

Week 01
_____________________________
Introduction to Python:
* Syntax
* Dynamic typing
* Arithmeric operands
* *if else* statement
* *for* loop
* arrays



Week 02
_____________________________

Input/Output. String functions.
