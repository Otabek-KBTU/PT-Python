Lab #2
==================
Solve problems using python:

* http://informatics.mccme.ru/mod/statements/view.php?id=2685
* http://informatics.mccme.ru/mod/statements/view3.php?id=2685&chapterid=3117
* http://informatics.mccme.ru/mod/statements/view3.php?id=2685&chapterid=3118
* http://informatics.mccme.ru/mod/statements/view3.php?id=2685&chapterid=3119
* http://informatics.mccme.ru/mod/statements/view3.php?id=2685&chapterid=3120
* http://informatics.mccme.ru/mod/statements/view3.php?id=2685&chapterid=3121
* http://informatics.mccme.ru/mod/statements/view3.php?id=2685&chapterid=3122
* http://informatics.mccme.ru/mod/statements/view3.php?id=2685&chapterid=3122
* http://informatics.mccme.ru/mod/statements/view3.php?id=2685&chapterid=3123
* http://informatics.mccme.ru/mod/statements/view3.php?id=2685&chapterid=3124
* http://informatics.mccme.ru/mod/statements/view3.php?id=2685&chapterid=3125
* http://informatics.mccme.ru/mod/statements/view3.php?id=2685&chapterid=3126

Find anagrams
___________

Find all anagrams among russian words. Vocabulary is available in *anagrams* folder.

Hint: use **s.sort()**.


Create anagrams

__________

Write function to create anagram for given word. Example: dress - > sersd.


Anagram game
____________


Write simple anagram game:

* program prints an anagram
* user prints solution
* if solution is right increase points
* else decrease lives (3 lives given).




